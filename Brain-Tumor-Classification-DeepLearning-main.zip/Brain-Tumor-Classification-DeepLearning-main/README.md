# Brain-Tumor-Classification-Deep-Learningninig
---

"Deep Learning Gamaliel Marines.pdf" is my report.
